var nodeAtlas = require("node-atlas"),
	versionFrench = new nodeAtlas(),
	versionEnglish = new nodeAtlas(),
	versionTest = new nodeAtlas();

versionFrench.init({
	"generate": true,

	// Nouveau webconfig français pour la génération.
	"webconfig": "webconfig.generate.json"
}).generated(function() {
	versionEnglish.init({
		"generate": true,

		// Nouveau webconfig international pour la génération.
		"webconfig": "webconfig.generate.en.json"
	}).generated(function() {
		versionTest.init({
			"browse": "index.html",
			"directory": "../dist/"
		}).start();
	}).start();
}).start();