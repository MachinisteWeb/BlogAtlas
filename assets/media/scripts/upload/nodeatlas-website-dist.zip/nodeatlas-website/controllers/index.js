exports.changeVariation = function (params, next) {
    var NA = this,
        fs = NA.modules.fs,
        variation = params.variation;

    // On remplace « assets/content/ » par sa valeur dans le webconfig.
    fs.readFile("assets/" + NA.webconfig._content + "index.htm", "utf-8", function (err, content) {
        if (err) {
            return next(variation);
        }

        variation.common.content = content;
        next(variation);
    });
};