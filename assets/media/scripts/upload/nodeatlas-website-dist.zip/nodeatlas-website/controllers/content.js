exports.changeVariation = function (next, locals) {
    var NA = this,
        fs = NA.modules.fs;

    // On remplace « assets/content/ » par sa valeur dans le webconfig.
    fs.readFile("assets/" + NA.webconfig._content + locals.currentRoute.replace(".html", ".htm"), "utf-8", function (err, content) {
        if (err) {
            return next();
        }

        locals.common.content = content;

        next();
    });
};