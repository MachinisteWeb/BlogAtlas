exports.setModules = function () {
    var NA = this;

    NA.modules.marked = require("marked");
};

exports.setRoutes = function (next) {
    var NA = this,
        fs = NA.modules.fs,
        jsdom =  NA.modules.jsdom,
        async = NA.modules.async,
        marked = NA.modules.marked,
        route = NA.webconfig.routes;

    function toUrl(text) {
        return text.toLowerCase().replace(/'| |\(|\)|\/|\!|\?|,|\&|\;|\[|\]|\%/g, "-").replace(/-+/g, "-").replace(/^-/g, "").replace(/-$/g, "");
    }

    // On remplace le « README.md » par sa valeur dans le webconfig.
    fs.readFile(NA.webconfig._readme, "utf-8", function (err, content) {
        if (err) {
            return next();
        }

        var html = marked(content),
            dom = new jsdom.JSDOM(html),
            allRoutes = [],
            menu,

            // On remplace « table des matières » par sa valeur dans le webconfig.
            key = NA.webconfig._toc;

        Array.prototype.forEach.call(dom.window.document.querySelectorAll('h2, h3'), function (title) {
            title.setAttribute("id", toUrl(title.textContent));
        });

        Array.prototype.forEach.call(dom.window.document.querySelectorAll('h3[id="' + key + '"]'), function (title) {
            var toc = title.nextElementSibling;

            Array.prototype.forEach.call(toc.children, function (sublink) {
                var subtitle = sublink.children[0],
                    url = encodeURIComponent(toUrl(subtitle.textContent)) + ".html";

                subtitle.setAttribute("href", url);

                Array.prototype.forEach.call(sublink.querySelectorAll('li'), function (sublink) {
                    var subtitle = sublink.children[0];

                    subtitle.setAttribute("href", url + "#" + encodeURIComponent(toUrl(subtitle.textContent)));

                    if (toUrl(subtitle.textContent) === key) {
                        sublink.parentNode.removeChild(sublink);
                    }
                });
            });

            menu = function (next) {

                // On remplace « assets/content/ » par sa valeur dans le webconfig.
                fs.writeFile("assets/" + NA.webconfig._content + "index.htm", title.outerHTML + toc.outerHTML, function () {
                    toc.parentNode.removeChild(toc);
                    title.parentNode.removeChild(title);

                    next();
                });
            };
        });

        function nextUntil(title, selector) {
            var htmlElement = title,
                nextUntil = [],
                until = true;
            while (htmlElement = htmlElement.nextElementSibling) {
                (until && htmlElement && !htmlElement.matches(selector)) ? nextUntil.push(htmlElement) : until = false;
            }
            return nextUntil;
        }

        Array.prototype.forEach.call(dom.window.document.getElementsByTagName('h2'), function (title) {
            allRoutes.push(function (nextRoute) {
                var content = nextUntil(title, "h2");

                // On remplace « assets/content/ » par sa valeur dans le webconfig.
                fs.writeFile("assets/" + NA.webconfig._content + encodeURIComponent(title.getAttribute("id")) + ".htm", title.outerHTML + content.map(function (element) { return element.outerHTML; }).join(''), function () {
                    route["/" + encodeURIComponent(title.getAttribute("id")) + ".html"] = {
                        "view": "content.htm",
                        "controller": "content.js"
                    };

                    nextRoute();
                });
            });
        });

        menu(function () {
            async.parallel(allRoutes, function() {
                next();
            });
        });
    });
};