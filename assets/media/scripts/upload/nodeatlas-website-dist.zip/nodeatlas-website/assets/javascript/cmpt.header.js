// On se créer (ou surcharge) les namespaces (existant ou non).
var website = window.website || {};
website.component = website.component || {};

// On créer un constructeur Header pour les composants `.header`.
website.component.Header = function () {
	var publics = this;

	publics.name = "header";

	publics.init = function () {};
};