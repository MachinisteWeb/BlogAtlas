// On se créer (ou surcharge) les namespaces (existant ou non).
// Un namespace globale au site que l'on nomme `website`.
var website = window.website || {};

// Un namespace réservé aux composants que l'on nomme `website.component`.
website.component = website.component || {};

// On encapsule les mécanismes des fonctions globales 
// pour éviter la collision de variable.
// `publics` est ici l'équivalent de `website`.
(function (publics) {

    // On fait de `xhrRequest` une fonction globale `website.xhrRequest`.
    publics.xhrRequest = function(url, next) {
        var request = new XMLHttpRequest();

        if (location.protocol !== "file:") {
            request.open("GET", url, true);
            request.send();
        } else {
            return next(new Error("Impossible to use AJAX in file system mode."));
        }

        request.addEventListener("load", function () {
            if (request.status < 200 && request.status >= 400) {
                return next(new Error("The server was reached, but with no correct response."));
            }
            next(null, request.responseText);
        });

        request.addEventListener("error", function () {
            return next(new Error("The server is unreachable."));
        });
    };

    // On fait de `xhrFallback` une fonction globale `website.xhrFallback`.
    publics.xhrFallback = function (url) {
        location.href = encodeURIComponent(url) + ".html";
    };

    // On créer une fonction d'initialisation pour tout le site.
    // Qui va charger tous les composants.
    publics.init = function () {
        var links = document.querySelectorAll(".navigation--home a, .navigation--menu a"),
            fragmentPath = document.body.getAttribute("data-content"),
            urlRelativeSubPath = document.body.getAttribute("data-subpath");

        // On charge chaque comportement de composant.
        (new website.component.Header()).init();
        (new website.component.Navigation()).init();
        (new website.component.Content()).init(links, fragmentPath, urlRelativeSubPath);     
    };

// On passe l'objet website pour l'alimenter avec des fonctions globales.
}(website));

website.init();