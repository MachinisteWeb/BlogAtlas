// On se créer (ou surcharge) les namespaces (existant ou non).
var website = window.website || {};
website.component = website.component || {};

// On créer un constructeur Content pour les composants `.content`.
website.component.Content = function () {
	var publics = this;

	publics.name = "content";

	// On créer une fonction d'instance `updateContentByClick` 
	// en passant en paramètre le nécessaire pour qu'elle fonctionne.
	publics.updateContentByClick = function (links, fragmentPath, urlRelativeSubPath) {
		[].forEach.call(links, function (link) {
			link.addEventListener("click", function (e) {
				var urn = link.getAttribute("href").replace(".html", "");
				e.preventDefault();

		        website.xhrRequest(fragmentPath + encodeURIComponent(urn) + ".htm", function (err, response) {
		            if (err) {
		                return website.xhrFallback(urn);
		            }

		    		history.pushState(urn, null, urlRelativeSubPath + "/" + urn + ".html");

		    		// On se sert d'un nom de classe dynamique et publique pour le changer en cas de besoin.
				    document.getElementsByClassName(publics.name + "--inner")[0].innerHTML = response;
				});
			});
		});
	};

	// On créer une fonction d'instance `updateContentByHistoryBack`.
	publics.updateContentByHistoryBack = function () {
		window.addEventListener("popstate", function (e) {
		    if (e.state) {
		        website.xhrRequest("content/" + encodeURIComponent(e.state) + ".htm", function (err, response) {
		            if (err) {
		                return website.xhrFallback(e.state);
		            }

		            // On se sert d'un nom de classe dynamique et publique pour le changer en cas de besoin.
				    document.getElementsByClassName(publics.name + "--inner")[0].innerHTML = response;
		        });
		    } else {
		        history.back();
		    }
		});
	};

    // On créer une fonction d'initialisation pour la classe, un raccourci.
    // Et on l'alimente et execute toutes les fonctions utiles.
	publics.init = function (links, fragmentPath, urlRelativeSubPath) {
		publics.updateContentByClick(links, fragmentPath, urlRelativeSubPath);
		publics.updateContentByHistoryBack();
	};
};