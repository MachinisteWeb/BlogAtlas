// On se créer (ou surcharge) les namespaces (existant ou non).
var website = window.website || {};
website.component = website.component || {};

// On créer un constructeur Navigation pour les composants `.navigation`.
website.component.Navigation = function () {
	var publics = this;

	publics.name = "navigation";

	publics.init = function () {};
};