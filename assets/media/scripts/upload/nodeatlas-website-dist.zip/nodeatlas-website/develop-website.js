// On récupère l'API NodeAtlas.
var nodeAtlas = require("node-atlas"),

	// On créé une instance pour générer la version française.
	versionFrench = new nodeAtlas(),

	// On créé une instance pour générer la version internationale.
	versionEnglish = new nodeAtlas();

// On paramètre la version française et on la lance.
versionFrench.run({
	"browse": true
});

// On paramètre la version internationale et on la lance.
versionEnglish.run({
	"webconfig": "webconfig.en.json"
});