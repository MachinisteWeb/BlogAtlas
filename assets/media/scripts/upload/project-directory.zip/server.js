require('node-atlas')().run({
    browse: true
});