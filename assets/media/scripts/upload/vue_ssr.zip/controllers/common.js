/* jslint node: true */
exports.changeDom = function (next, locals, request, response) {
	var NA = this,

		readFile = NA.modules.fs.readFile,
		join = NA.modules.path.join,

		Vue = require("vue"),
		VueRouter = require("vue-router"),
		VueServerRenderer = require("vue-server-renderer"),

		path = join(NA.serverPath, NA.webconfig.viewsRelativePath),
		view = join(path, locals.routeParameters.view + ".htm"),
		model = join(path, locals.routeParameters.view + ".js"),
		appModel = join(path, "app.js"),
		appView = join(path, "app.htm"),

		renderer = VueServerRenderer.createRenderer({
			template: locals.dom
		});

	Vue.use(VueRouter);

	if (!NA.webconfig.cache) {
		delete require.cache[model];
	}

	readFile(view, "utf-8",  function (error, template) {
		var component = Vue.component(locals.routeParameters.view, require(model)(template));

		readFile(appView, "utf-8", function (error, template) {
			var router = new VueRouter({
					routes: [{
						path: locals.routeParameters.url,
						component: component
					}]
				}),
				webconfig = {
					routes: NA.webconfig.routes
				},
				stream = renderer.renderToStream(new Vue(require(appModel)(template, router, webconfig)), locals);

			router.push(locals.routeParameters.url);

			stream.on('data', function (chunk) {
				response.write(chunk);
			});

			stream.on('end', function () {
				response.end();
			});
		});
	});
};