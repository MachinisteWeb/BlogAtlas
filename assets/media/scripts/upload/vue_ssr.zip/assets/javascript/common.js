if (window.location.pathname.slice(-1) !== '/') {
	window.location = window.location.pathname + '/';
}

window.module = {};

function xhr(url) {
	return new Promise(function (resolve, reject) {
		var request = new XMLHttpRequest(),
			type = url.match(/\.(js(on)?|html?)$/g, '$0')[0];

		request.addEventListener("load", function () {
			if (request.status < 200 && request.status >= 400) {
				reject(new Error("We reached our target server, but it returned an error."));
			}

			if (type === '.js') {
				resolve(eval(request.responseText));
			} else if (type === '.json') {
				resolve(JSON.parse(request.responseText));
			} else {
				resolve(request.responseText);
			}

		});

		request.addEventListener("error", function () {
			reject(new Error("There was a connection error of some sort."));
		});

		request.open("GET", location.origin + '/' + url, true);
		request.send();
	});
}

Promise.all([
	xhr("views-models/app.js"),
	xhr("views-models/app.htm"),
	xhr("routes.json")
]).then(function (files) {
	var vm,
		routes = [],
		router,
		model = files[0],
		template = files[1],
		webconfig = {
			routes: files[2]
		},
		keys = Object.keys(webconfig.routes);

	keys.forEach(function (key) {
		var route = {},
			name = webconfig.routes[key].view,
			model,
			template;

		route.name = name;
		route.path = webconfig.routes[key].url;

		route.component = function (resolve) {
			Promise.all([
				xhr("views-models/" + name + ".js"),
				xhr("views-models/" + name + ".htm"),
			]).then(function (files) {
				model = files[0];
				template = files[1];

				resolve(model(template));
			});
		};

		routes.push(route);
	});

	router = new VueRouter({
		mode: 'history',
		fallback: false,
		base: '/',
		routes: routes
	});

	vm = new Vue(model(template, router, webconfig));

	router.onReady(function () {
		vm.$mount('.app');
	});
});