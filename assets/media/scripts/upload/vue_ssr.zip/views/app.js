module.exports = function (template, router, webconfig) {
	return {
		name: 'app',
		template: template,
		router: router,
		data: {
			webconfig: webconfig
		}
	};
};