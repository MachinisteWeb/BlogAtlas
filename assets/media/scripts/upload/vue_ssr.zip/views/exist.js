module.exports = function (template) {
	return {
		name: 'content',
		template: template,
		data: function () {
			return {};
		}
	};
};