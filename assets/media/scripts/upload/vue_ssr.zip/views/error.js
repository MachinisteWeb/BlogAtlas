module.exports = function (template) {
	return {
		name: 'error',
		template: template,
		data: function () {
			return {};
		}
	};
};