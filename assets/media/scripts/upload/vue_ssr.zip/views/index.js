module.exports = function (template) {
	return {
		name: 'index',
		template: template,
		data: function () {
			return {};
		}
	};
};